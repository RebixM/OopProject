﻿namespace GymManagementApp.Models
{
    public interface IProductRepository
    {
        IEnumerable<IProductRepository> GetAll();
        IProductRepository GetProductById(int id);
    }
}
