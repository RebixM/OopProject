﻿using System.Security.Cryptography.X509Certificates;

namespace GymManagementApp.Models
{
    public class ProductRepository : IProductRepository
    {
        private List<Product> _products;

        public ProductRepository()
        {
            //inicjalization: random data
            _products = new List<Product>
            {
                new Product { Id = 1.Name = "Product1", Price = 10.00, Description = "Opis1"},
                new Product { Id = 1.Name = "Product2", Price = 20.00, Description = "Opis2"},
                new Product { Id = 1.Name = "Product3", Price = 30.00, Description = "Opis3"}
            };
        }
        public IEnumerable<Product> GetAllProducts()
        {
            {
                return _products;
            }
        
        }
        public Product GetProductById(int id)
        {
            return _products.FirstOrDefault(p => p.Id == id);
        }
    }
}
