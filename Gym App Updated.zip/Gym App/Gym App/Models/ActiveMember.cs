﻿using System;

// Klasa abstrakcyjna
abstract class ActiveMember
{
    public abstract void Parameters();
}

// Klasa Active dziedzicząca po klasie ActiveMember
class Active : ActiveMember
{
    public override void Parameters()
    {
        Console.WriteLine("Użytkownik jest aktywny");
    }
}
partial class Program
{
    static void Main()
    {
        ActiveMember Active = new Active();
        Active.Parameters(); 

    }
}
