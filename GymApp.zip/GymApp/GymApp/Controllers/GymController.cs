﻿using GymApp.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace GymApp.Controllers
{
    public class GymController : Controller
    { 
        private static IList<MemberModel> members = new List<MemberModel>()
        {
            new MemberModel() { Id = 1, FirstName = "John", LastName = "Doe", Age = 25, IsActive = true },
            new MemberModel() { Id = 2, FirstName = "Julia", LastName = "Rose", Age = 37, IsActive = false }
        };
    
        // GET: GymController
        public ActionResult Index()
        {
            return View(members);
        }

        // GET: GymController/Details
        public ActionResult Details(int id)
        {
            return View(members.FirstOrDefault(x => x.Id == id));
        }

        // GET: GymController/Create
        public ActionResult Create()
        {
            return View(new MemberModel());
        }

        // POST: GymController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(MemberModel memberModel)
        {
            memberModel.Id = members.Count + 1;
            members.Add(memberModel);

            return RedirectToAction(nameof(Index));
        }

        // GET: GymController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: GymController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: GymController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: GymController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
